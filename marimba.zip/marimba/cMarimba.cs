﻿using System;
using System.Collections.Generic;
using System.Text;

namespace marimba
{
    class cMarimba
    {
        public void playNote(string note)
        {
            Console.WriteLine("marimba plays the note " + note);
        }

    }
}
